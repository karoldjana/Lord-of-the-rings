# Lord of the Rings SDK
This is an SDK project for the Lord of the Rings' fans. Is part of the Liblab hometask.

It consumes the lord of the rings API.
Here you can find its documentation: https://the-one-api.dev/documentation


## Installation
Run the following to install:

```python
pip install lotr_sdk
```

## Usage

```python
from test import *
```
A menu will appear with all the instructions to follow. It will require keyboard inputs.

